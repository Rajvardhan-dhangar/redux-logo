export const stopaction ={
    type : "roted",
    payload : false
}