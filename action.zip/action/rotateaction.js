const rotateAction = (payload) => {
    return {
      type: "rotate",
      payload
    }
  }
  export default rotateAction;